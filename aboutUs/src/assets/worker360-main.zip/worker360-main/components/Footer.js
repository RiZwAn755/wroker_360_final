import React from 'react'
import Link from 'next/link'
const Footer = () => {
  return (
    <footer className='bg-purple-800 text-white flex justify-around px-4 h-14 items-center'>
  <div>Copyright &copy; {new Date().getFullYear()} <span className='text-black'>Worker</span> <span className='text-orange-400'>360</span> - All Right Reserved!</div>
  <div className="flex gap-6">
          <Link href="https://facebook.com/yourpage" target="_blank" rel="noopener noreferrer">
            <img src="/fb.webp" alt="Facebook" width="30" height="30" />
          </Link>
          <Link  className="invert" href="https://twitter.com/yourpage" target="_blank" rel="noopener noreferrer">
            <img src="/X.webp" alt="Twitter" width="40" height="30" />
          </Link>
          <Link href="https://instagram.com/yourpage" target="_blank" rel="noopener noreferrer">
            <img src="/insta.jpg" alt="Instagram" width="30" height="30" />
          </Link>
          <Link href="https://linkedin.com/in/yourpage" target="_blank" rel="noopener noreferrer">
            <img src="/linkedin.webp" alt="LinkedIn" width="30" height="30" />
          </Link>
          <Link href="https://github.com/yourprofile" target="_blank" rel="noopener noreferrer">
            <img src="/github.webp" alt="GitHub" width="30" height="30" />
          </Link>
        </div>
</footer>
  )
}

export default Footer
"use client"
import { useSession, signIn, signOut } from "next-auth/react"
import React, { useState } from 'react'
import Link from 'next/link'
import { useRouter } from "next/navigation"
import Image from 'next/image'
const Navbar = () => {
    const { data: session } = useSession()
    return (
        <nav className='h-24 fixed rounded-xl w-full border-b-2 mt-0 border-black bg-purple-400 flex flex-col md:flex-row md:justify-between justify-center px-6 items-center text-white'>
        <div className="flex items-center">
          <Link href={'/'}>
            <div>
              <span className='text-black font-bold text-3xl'>Worker</span>
              <span className='text-orange-400 font-bold text-3xl'> 360</span>
            </div>
          </Link>
        </div>
      
        <div className="flex gap-6 text-2xl text-black hover:text-gray-950 items-center">    
          <Link href="/"><p className="hover:underline">Home</p></Link>
          <Link href="/contacts"><p className="hover:underline">Worker Registration</p></Link>
          <Link href="/about"><p className="hover:underline">About Us</p></Link>
          
          {session ? (
            <button 
              className="bg-red-500 text-white px-4 py-1 rounded-md hover:bg-purple-600 transition"
              onClick={() => signOut()}
            >
              Logout
            </button>
          ) : (
            <Link href="/login">
              <button className="bg-gray-500 text-white px-4 py-1 rounded-md hover:bg-purple-600 transition">
                Login
              </button>
            </Link>
          )}
        </div>
      </nav>
      
    )
  };
  export default Navbar;
  
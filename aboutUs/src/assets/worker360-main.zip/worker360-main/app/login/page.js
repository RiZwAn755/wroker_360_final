import Login from '@/components/Login'
import React from 'react'

const page = () => {
  return (
    <Login />
  )
}

export default page

export const metadata = {
  title: 'Login - Get Me A Chai',
  
}
import React from 'react';
import clientPromise from '@/lib/mongodb';
import Link from 'next/link';

const Hireworker = async () => {
  const client = await clientPromise;
  const db = client.db("Worker360");
  const collection = db.collection("contacts");
  const data = await collection.find({}).toArray();
  
  return (
    <>
      <div className="section">
        <h1 className="sectionHeading">Top Workers in Your Area</h1>

        {data.length > 0 ? (
          data.map((worker, index) => (
            <div className="card" key={index}>
              <img className="photo" src="/men.jpg" alt={worker.name} />
              <p>
                Occupation: {worker.occupation} <br />
                Experience: {worker.experience} years <br />
                Wage per hour: ${worker.wage}
              </p>
              
                <button className="btnn">Hire me</button>
              
            </div>
          ))
        ) : (
          <p>No workers available</p>
        )}
      </div>
    </>
  );
};

export default Hireworker;

import Image from "next/image";
import Link from "next/link";
import Contactpage from "./contacts/page";
import AboutPage from "./about/page";  

export default function Home() {
  return (
    <>
      <div className="Parent">
              
              <div className='Image'>
                <img src="/bg.png" alt="" />
              </div>

              <div className='Texts'>

                <div className= 'Text1'>
                      Services  At Your DoorStep 
                </div>

                <div className='Text2'>
                   
                        From Home Repairs To Beauty
                        Serives 
                        <br />We Bring Trusted 
                        <br />
                        Professionals To You WhereEver You Are.                     

                </div>
                
                <div className='btn'  >
                <Link href={'/hireworker'}> <button className='click' >
                    <h3>Hire Worker</h3>
                   </button></Link> 
              </div>

              </div>

              
            
        </div>

        {/* <div className="bg-black h-[2px] my-8"></div> */}
        <div>
        <Contactpage/>
        </div>

        <div className="bg-black h-[2px] my-8"></div>

        <div>
        <AboutPage/>
        </div>

        
    </>
     );
}

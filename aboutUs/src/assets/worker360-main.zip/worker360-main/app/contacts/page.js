"use client"; // Ensure it's a Client Component
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import React, { useState, useEffect } from 'react';

function Contactpage() {
  const [inputs, setInputs] = useState({
    name: "",
    states: "",
    email: "",
    phone: "",
    dob: "",
    pic: "",
    occupation: "",
    experience: "",
    message: "",
    wage: "",  // Removed space
    gender: "", // Removed space
  });

  const [phoneError, setPhoneError] = useState("");

  const handleChange = (e) => {
    setInputs((prevState) => ({
      ...prevState,
      [e.target.name]: e.target.value,
    }));

    if (e.target.name === "phone") {
      const phoneNumber = e.target.value.replace(/\D/g, '');
      if (phoneNumber.length !== 10) {
        setPhoneError("Phone number must be 10 digits.");
      } else {
        setPhoneError("");
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (phoneError) return;

    const myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");

    const raw = JSON.stringify({
        name: inputs.name,
        email: inputs.email,
        gender: inputs.gender,
        states: inputs.states,
        pic: inputs.pic,
        phone: inputs.phone,
        dob: inputs.dob,
        occupation: inputs.occupation,
        experience: inputs.experience,
        wage: inputs.wage,
        message: inputs.message
      });
      

const requestOptions = {
  method: "POST",
  headers: myHeaders,
  body: raw,
  redirect: "follow"
};

let r= await fetch("http://localhost:3000/api/add", requestOptions)

const result=await r.json();
if(result.success){ 
    toast.success(result.message)
    setInputs({name: "", states: "", email: "", phone: "", pic:" ",dob: "", occupation: "", experience: "", message
    : "", wage:" ",gender:" "})
   }
   else{
     toast.error(result.message)
   }
}

  return (
    <>
      <section className='grid grid-cols-2 bg-purple-200 min-h-screen p-4'>
        <div className="flex justify-center flex-col ml-[10vw] gap-3 mt-44">
          <h2 className='text-2xl font-bold text-center mb-4'>Registration Form (For workers)</h2>
          <form className="flex flex-col space-y-4">
            <label htmlFor="name" className="font-medium">Name:</label>
            <input type="text" id="name" name="name" placeholder="Enter your name"
              className="border border-gray-300 p-2 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              onChange={handleChange} value={inputs.name} />

            <div className="gender">
              <p className="font-medium">Your Gender</p>
              <div className="flex space-x-4">
                <label className="flex items-center space-x-2">
                  <input type="radio" id="male" name="gender" value="male"
                    onChange={handleChange} checked={inputs.gender === "male"} />
                  <span>Male</span>
                </label>
                <label className="flex items-center space-x-2">
                  <input type="radio" id="female" name="gender" value="female"
                    onChange={handleChange} checked={inputs.gender === "female"} />
                  <span>Female</span>
                </label>
              </div>
            </div>

            <label htmlFor="image" className="font-medium">Upload your passport-size photo:</label>
            <input type="text" id="pic" name="pic" placeholder="Enter your pic url"
              className="border border-gray-300 p-2 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              onChange={handleChange} value={inputs.pic} />

            <label htmlFor="states" className="font-medium">State:</label>
            <select id="states" name="states" value={inputs.states} onChange={handleChange}
              className="border border-gray-300 p-2 rounded-md">
              <option value="" disabled>--Select State--</option>
              <option value="Andhra Pradesh">Andhra Pradesh</option>
              <option value="Maharashtra">Maharashtra</option>
              <option value="Delhi">Delhi</option>
              <option value="Karnataka">Karnataka</option>
            </select>

            <label htmlFor="email" className="font-medium">Email:</label>
            <input type="email" id="email" name="email" placeholder="Enter your email"
              className="border border-gray-300 p-2 rounded-md" onChange={handleChange} value={inputs.email} />

            <label htmlFor="phone" className="font-medium">Phone:</label>
            <input type="text" id="phone" name="phone" placeholder="Enter your phone number"
              className="border border-gray-300 p-2 rounded-md" onChange={handleChange} value={inputs.phone} />
            {phoneError && <p className="text-red-500">{phoneError}</p>}

            <label htmlFor="dob" className="font-medium">Date of Birth:</label>
            <input type="date" id="dob" name="dob"
              className="border border-gray-300 p-2 rounded-md" onChange={handleChange} value={inputs.dob} />

            <label htmlFor="occupation" className="font-medium">Occupation:</label>
            <select id="occupation" name="occupation" value={inputs.occupation} onChange={handleChange}
              className="border border-gray-300 p-2 rounded-md">
              <option value="" disabled>--Select Occupation--</option>
              <option value="House Cleaner">House Cleaner</option>
              <option value="Cook">Cook</option>
              <option value="Electrician">Electrician</option>
            </select>

            <label htmlFor="experience" className="font-medium">Experience (in years):</label>
            <input type="text" id="experience" name="experience" placeholder="Enter your experience"
              className="border border-gray-300 p-2 rounded-md" onChange={handleChange} value={inputs.experience} />

            <label htmlFor="wage" className="font-medium">Wage (per hour):</label>
            <input type="text" id="wage" name="wage" placeholder="Enter your wage"
              className="border border-gray-300 p-2 rounded-md" onChange={handleChange} value={inputs.wage} />

            <label htmlFor="message" className="font-medium">Message:</label>
            <textarea id="message" name="message" rows="4" placeholder="Enter your message"
              className="border border-gray-300 p-2 rounded-md" onChange={handleChange} value={inputs.message}></textarea>

            <button type="submit" onClick={handleSubmit}
              className="bg-blue-500 text-white p-2 rounded-md hover:bg-blue-600 transition">
              Send Details
            </button>
          </form>
        </div>
        <div className="flex flex-col items-start justify-start space-y-4 ml-[10vw] mt-44 w-full max-w-md">
  <h2 className="text-2xl font-bold text-left">Contact Details</h2>

  <p className="text-lg font-semibold">Address: <span className="font-normal">A.D.A Colony, Prayagraj, India</span></p>
  
  <p className="text-lg font-semibold">Email: <span className="font-normal">Worker 360@gmail.com</span></p>
  
  <p className="text-lg font-semibold">Phone: <span className="font-normal">+91 9587283091</span></p>
  <ToastContainer />
</div>
      </section>
    </>
  );
}

export default Contactpage;
